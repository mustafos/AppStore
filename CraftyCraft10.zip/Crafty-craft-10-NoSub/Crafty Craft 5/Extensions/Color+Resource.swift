//
//  Color+Resource.swift
//  Crafty Craft 5
//
//  Created by dev on 01.08.2023.
//  Copyright © 2023 Noname Digital. All rights reserved.
//

import SwiftUI

extension Color {
    static let darkGreenBackground = Color("darkGreenBackground")
    static let lightGreenBachgroundColor = Color("lightGreenBachgroundColor")
    
}
