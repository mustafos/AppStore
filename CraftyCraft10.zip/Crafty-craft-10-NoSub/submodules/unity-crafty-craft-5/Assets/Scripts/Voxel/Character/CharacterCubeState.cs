namespace Voxel.Character
{
    public enum CharacterCubeState
    {
        Visible, 
        Invisible
    }
}