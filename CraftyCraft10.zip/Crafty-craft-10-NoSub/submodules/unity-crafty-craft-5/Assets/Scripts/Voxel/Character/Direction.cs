namespace Voxel.Character
{
    public enum Direction: byte
    {
        Front = 0,
        Up = 1,
        Back = 2,
        Down = 3,
        Left = 4,
        Right = 5,
    }
}