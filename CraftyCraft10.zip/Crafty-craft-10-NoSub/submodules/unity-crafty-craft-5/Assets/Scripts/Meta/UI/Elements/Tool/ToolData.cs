﻿using System;

namespace Meta.UI.Elements.Tool
{
  [Serializable]
  public class ToolData
  {
    public ToolId ToolId;
    public ToolElement Element;
  }
}