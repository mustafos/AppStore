﻿using UnityEngine.Events;

public class SliderOnChangeEndEvent : UnityEvent<float>
{

}
