using System;
using System.Collections.Generic;

namespace Voxel.Character
{
    [Serializable]
    public class Cube
    {
        public List<MeshData> faces = new List<MeshData>();
    }
}