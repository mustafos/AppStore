﻿namespace Meta.UI.Elements.Tool
{
  public enum ToolId
  {
    Pallet = 1,
    PencilSizeSelection = 2,
    EracerSizeSelection,
    NoiseSizeSelection,
  }
}