//
//  UITabBar+Title.swift
//  Crafty Craft 5
//
//  Created by dev on 25.07.2023.
//  Copyright © 2023 Noname Digital. All rights reserved.
//

import UIKit

//extension UITabBar {
//    // Workaround for iOS 11's new UITabBar behavior where on iPad, the UITabBar inside
//    // the Master view controller shows the UITabBarItem icon next to the text
//    override open var traitCollection: UITraitCollection {
////        if #unavailable(iOS 17) {
////            if Device.iPad {
////                return UITraitCollection(horizontalSizeClass: .compact)
////            }
////        }
//        
//        return super.traitCollection
//    }
//}
