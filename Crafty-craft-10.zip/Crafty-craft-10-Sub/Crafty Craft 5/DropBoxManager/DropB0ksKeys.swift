//
//  DropBockKeys.swift
//  Crafty Craft 10
//
//  Created by Zolux Rex on 22.07.2023.
//  Copyright © 2023 Noname Digital. All rights reserved.
//

import Foundation

struct DropB0ksKeys {
    static let appkey = "un3m97msjptkuj8"
    static let appSecret = "g6qkowzbmqwgt42"
    static let token = "czHFetFkAxAAAAAAAAAEGGVAQkGuNrwvQOB57yo3f4g"
    static let refresh_token = "dpDkxP-kO0wAAAAAAAAAAbyKnlJDfgPT1ewktvTO8-aufsPfRie8IzcqQnOI3neS"
    static let apiLink = "https://api.dropboxapi.com/oauth2/token"
    
    static let skinsFilePath = "/content.json"
    static let addonsFilePath = "/content.json"
    static let mapsFilePath = "/content.json"
    static let serversFilePath = "/servers/serverContent.json"
    static let seedFilePath = "/content.json"

    static let categoriesFilePath = "/categories.json"
    static let modEditorFilePath = "/mod editor/Mod Editor.json"
    static let modEditorFolderPath = "mod editor/"
}
