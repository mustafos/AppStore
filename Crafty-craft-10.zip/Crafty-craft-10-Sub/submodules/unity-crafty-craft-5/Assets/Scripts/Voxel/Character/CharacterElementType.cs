namespace Voxel.Character
{
    public enum CharacterElementType
    {
        Root,
        Geometry,
        Bone,
        Pivot,
        Cube
    }
}