HSV color picker using Unity UI.
Github https://github.com/judah4/HSV-Color-Picker-Unity

Usage:
Drag picker prefab onto a UI canvas.

Setup:
On the color picker setup section.

Show Rgb: Show RGB sliders.

Show Hsv: Show HSV sliders.

Show Alpha: Show the alpha slider.

Show Color Box: Show the larger color selection box and color column.

Show Color Slider Toggle: Show the button to toggle the HSV and RGB sliders.

Show Header: Options to show the top header with color preview and hex code.
* Hide: Hide the top header.  
* Show Color: Show only the color preview in the header.  
* Show Color Code: Show only the color code in the header.  
* Show All: Show the entire top header.  

Color Presets:
The prefabs starts with 4 colors in the color presets. This can be updated in the Setup section of the picker prefab.  
Set the Preset Colors Id for different shared list between color pickers.