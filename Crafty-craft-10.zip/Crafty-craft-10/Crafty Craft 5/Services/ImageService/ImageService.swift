//
//  ImageService.swift
//  Crafty Craft 5
//
//  Created by dev on 22.07.2023.
//  Copyright © 2023 Noname Digital. All rights reserved.
//

import UIKit

final class ImageService {

    // MARK: - Public API

    func image(for url: URL, completion: @escaping (UIImage?) -> Void) -> Cancellable {
        let dataTask = URLSession.shared.dataTask(with: url) { data, _, _ in
            // Helper
            var image: UIImage?

            defer {
                // Execute Handler on Main Thread
                DispatchQueue.main.async {
                    // Execute Handler
                    completion(image)
                }
            }

            if let data = data {
                // Create Image from Data
                image = UIImage(data: data)
            }
        }

        // Resume Data Task
        dataTask.resume()

        return dataTask
    }
}
