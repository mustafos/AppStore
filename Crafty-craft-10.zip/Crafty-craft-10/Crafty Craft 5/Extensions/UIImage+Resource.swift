//
//  UIImage+Resource.swift
//  Crafty Craft 5
//
//  Created by dev on 31.07.2023.
//  Copyright © 2023 Noname Digital. All rights reserved.
//

import UIKit

extension UIImage {
    static let cross_small = UIImage(named: "cross-small")
    static let search_item = UIImage(named: "Search Item")
}
