using System;

namespace Voxel.McData
{
    [Serializable]
    public class UV6DataElement
    {
        public float[] uv;
        public float[] uv_size;
    }
}